export const ADDPROF = "ADDPROFILE";


export const AddToprofile = (data) => ({
    type: ADDPROF,
    key:data
    
  });