import Login from "../Pages/Login";
import OTP from "../Pages/OTP";
import Signup from "../Pages/Signup";

export default function Contact_us(params) {
    return(
        <>
            <Signup/>
            <hr/>
            <Login/>
            <hr/>
            <OTP/>

        </>
    )
}